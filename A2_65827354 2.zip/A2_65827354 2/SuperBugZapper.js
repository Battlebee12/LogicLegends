// Vertex shader program
var VSHADER_SOURCE =
    'attribute vec4 a_Position;\n' +
    'attribute vec4 a_Color;\n' +
    'varying vec4 v_Color;\n' +
    'void main() {\n' +
    '   gl_Position = a_Position;\n' +
    '   v_Color = a_Color;\n' +
    '}\n';

// Fragment shader program
var FSHADER_SOURCE =
    'precision mediump float;\n' +
    'varying vec4 v_Color;\n' +
    'void main() {\n' +
    '   gl_FragColor = v_Color;\n' +
    '}\n';

var gamePoints = 0;
var playerPoints = 0;

function main() {
    var canvas = document.getElementById('webgl');
    var gl = canvas.getContext('webgl');
    if (!gl) {
        console.log('Failed to get the rendering context for WebGL');
        return;
    }

    if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
        console.log('Failed to initialize shaders.');
        return;
    }

    var BacNum = 4 + Math.floor(Math.random() * 6);
    var DiskRadius = 0.8;
    var MaxBacRadius = 0.2;
    var numPoints = 360;
    var threshold = 0.025;
    var growthIncrement = 2;

    var BacCenters = [];
    for (var i = 0; i < BacNum; i++) {
        var theta = Math.random() * 2 * Math.PI;
        BacCenters.push([DiskRadius * Math.cos(theta), DiskRadius * Math.sin(theta)]);
    }

    var BacColors = [];
    for (var i = 0; i < BacNum; i++) {
        BacColors.push([Math.random(), Math.random(), Math.random()]);
    }

    var sizeGrowthElement = document.getElementById('size_growth');

    canvas.addEventListener('click', function (event) {
        var rect = canvas.getBoundingClientRect();
        var mouseX = (event.clientX - rect.left) / canvas.width * 2 - 1;
        var mouseY = 1 - (event.clientY - rect.top) / canvas.height * 2;

        for (var i = 0; i < BacNum; i++) {
            var distX = BacCenters[i][0] - mouseX;
            var distY = BacCenters[i][1] - mouseY;
            var distance = Math.sqrt(distX * distX + distY * distY);
            if (distance <= MaxBacRadius) {
                BacCenters.splice(i, 1);
                BacColors.splice(i, 1);
                BacNum--;

                playerPoints += 5;
                document.getElementById('points').innerHTML = 'Player Points: ' + playerPoints;

                GlobalNumVertices = initVertexBuffers(gl, numPoints, DiskRadius, BacNum, BacCenters, BacColors, MaxBacRadius);
                if (GlobalNumVertices < 0) {
                    console.log('Failed to update buffers');
                    return;
                }

                break;
            }
        }
    });

    gl.clearColor(0, 0, 0, 1);
    var growthConditionMet = false;

    var tick = function () {
        var BacRadius = getBacScaleFactor() * MaxBacRadius;
        var sizeInMicrons = getBacSizeInMicrons(BacRadius);
        sizeGrowthElement.innerHTML = 'Bacteria Size: ' + sizeInMicrons.toFixed(2) + ' units';

        var GlobalNumVertices = initVertexBuffers(gl, numPoints, DiskRadius, BacNum, BacCenters, BacColors, BacRadius);
        if (GlobalNumVertices < 0) {
            console.log('Failed to set the positions of the vertices');
            return;
        }

        gl.clear(gl.COLOR_BUFFER_BIT);

        gl.drawArrays(gl.TRIANGLE_FAN, 0, GlobalNumVertices);
        for (var i = 1; i <= BacNum; i++) {
            gl.drawArrays(gl.TRIANGLE_FAN, i * GlobalNumVertices, GlobalNumVertices);
        }

        var gamePoints = 2 * sizeInMicrons;
        document.getElementById('game_points').innerHTML = 'Game Points: ' + gamePoints.toFixed(2);

        if (BacRadius >= MaxBacRadius && BacNum != 0) {
            document.getElementById('win_lose').innerHTML = 'You lost';
            endGame();
        }

        if(BacNum===0){
            document.getElementById('win_lose').innerHTML = 'Player wins ';
            endGame();

        }

        if (BacNum === 0 && gamePoints < playerPoints) {
            document.getElementById('win_lose').innerHTML = 'Player wins ';
            endGame();
        } 

        requestAnimationFrame(tick, canvas);
    };
    tick();
}


var startDate = Date.now() / 1000;

function getBacScaleFactor(size) {
    var currentDate = Date.now() / 1000;
    var diffDate = currentDate - startDate;
    return Math.min(1, diffDate / 15);
}

function getBacSizeInMicrons(radius) {
    return radius * 100;
}

function initVertexBuffers(gl, numPoints, DiskRadius, BacNum, BacCenters, BacColors, MaxBacRadius) {
    var circlePoints = [0.0, 0.0, 1.0, 1.0, 1.0];

    for (var i = 0; i <= numPoints; i++) {
        circlePoints.push(
            DiskRadius * Math.cos(i * 2 * Math.PI / numPoints),
            DiskRadius * Math.sin(i * 2 * Math.PI / numPoints)
        );
        circlePoints.push(1.0, 1.0, 1.0);
    }

    var GlobalNumVertices = circlePoints.length / 5;

    for (var i = 0; i < BacNum; i++) {
        circlePoints.push(BacCenters[i][0], BacCenters[i][1], BacColors[i][0], BacColors[i][1], BacColors[i][2]);
        for (var j = 0; j <= numPoints; j++) {
            circlePoints.push(
                BacCenters[i][0] + MaxBacRadius * Math.cos(j * 2 * Math.PI / numPoints),
                BacCenters[i][1] + MaxBacRadius * Math.sin(j * 2 * Math.PI / numPoints),
                BacColors[i][0], BacColors[i][1], BacColors[i][2]
            );
        }
    }

    circlePoints = new Float32Array(circlePoints);

    var vertexBuffer = gl.createBuffer();
    if (!vertexBuffer) {
        console.log('Failed to create the buffer object');
        return -1;
    }

    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, circlePoints, gl.DYNAMIC_DRAW);

    var FSIZE = circlePoints.BYTES_PER_ELEMENT;
    var a_Position = gl.getAttribLocation(gl.program, 'a_Position');
    if (a_Position < 0) {
        console.log('Failed to get the storage location of a_Position');
        return -1;
    }

    gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, FSIZE * 5, 0);
    gl.enableVertexAttribArray(a_Position);

    var a_Color = gl.getAttribLocation(gl.program, 'a_Color');
    if (a_Color < 0) {
        console.log('Failed to get the storage location of a_Color');
        return -1;
    }

    gl.vertexAttribPointer(a_Color, 3, gl.FLOAT, false, FSIZE * 5, FSIZE * 2);
    gl.enableVertexAttribArray(a_Color);

    return GlobalNumVertices;
}
